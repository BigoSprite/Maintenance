member/info blade php

{{$age}} {{$name}}

注意是双花括号