member/info blade php

<?php echo e($age); ?> <?php echo e($name); ?>


注意是双花括号